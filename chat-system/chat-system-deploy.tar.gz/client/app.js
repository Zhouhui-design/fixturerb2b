class ChatApp {
    constructor() {
        this.socket = null;
        this.currentUser = null;
        this.currentChat = null;
        this.translationEnabled = false;
        this.localStream = null;
        this.peerConnection = null;
        this.rtcConfig = {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' }
            ]
        };
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.checkExistingSession();
    }
    
    bindEvents() {
        document.getElementById('login-btn').addEventListener('click', () => this.handleAuth());
        document.getElementById('logout-btn').addEventListener('click', () => this.logout());
        
        document.getElementById('search-user-input').addEventListener('input', (e) => this.handleSearch(e.target.value));
        
        document.getElementById('send-message-btn').addEventListener('click', () => this.sendMessage());
        document.getElementById('message-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        document.getElementById('translate-toggle-btn').addEventListener('click', () => this.toggleTranslation());
        
        document.getElementById('voice-message-btn').addEventListener('click', () => this.startVoiceRecording());
        
        document.getElementById('video-call-btn').addEventListener('click', () => this.startVideoCall());
        document.getElementById('end-call-btn').addEventListener('click', () => this.endVideoCall());
        
        document.getElementById('remark-btn').addEventListener('click', () => this.openRemarkModal());
        
        document.getElementById('social-links-btn').addEventListener('click', () => this.openSocialLinksModal());
        document.getElementById('suggestions-btn').addEventListener('click', () => this.openSuggestionsModal());
        document.querySelectorAll('.close-modal-btn').forEach(btn => {
            btn.addEventListener('click', () => this.closeAllModals());
        });
        
        document.getElementById('save-social-links-btn').addEventListener('click', () => this.saveSocialLinks());
        
        document.getElementById('submit-suggestion-btn').addEventListener('click', () => this.submitSuggestion());
        
        document.getElementById('save-remark-btn').addEventListener('click', () => this.saveRemark());
    }
    
    checkExistingSession() {
        const savedUser = localStorage.getItem('chat_user');
        if (savedUser) {
            const userData = JSON.parse(savedUser);
            this.login(userData.username, userData.token);
        }
    }
    
    async handleAuth() {
        const username = document.getElementById('username-input').value.trim();
        const errorDiv = document.getElementById('auth-error');
        
        if (!username || username.length < 3) {
            errorDiv.textContent = 'Username must be at least 3 characters';
            return;
        }
        
        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                this.login(username, data.token);
                localStorage.setItem('chat_user', JSON.stringify({
                    userId: data.userId,
                    username: data.username,
                    token: data.token
                }));
            } else {
                errorDiv.textContent = data.error;
            }
        } catch (err) {
            errorDiv.textContent = 'Connection error. Please try again.';
        }
    }
    
    login(username, token) {
        this.currentUser = { username, token };
        
        this.socket = io({
            auth: { token }
        });
        
        this.setupSocketListeners();
        
        document.getElementById('auth-screen').classList.remove('active');
        document.getElementById('chat-screen').classList.add('active');
        document.getElementById('current-username').textContent = username;
        
        this.loadConversations();
    }
    
    setupSocketListeners() {
        this.socket.on('receive_message', (data) => {
            if (this.currentChat === data.from) {
                this.displayMessage(data, 'received');
                this.markMessageAsRead(data.id);
            } else {
                this.loadConversations();
            }
        });
        
        this.socket.on('message_sent', (data) => {
            console.log('Message sent:', data);
        });
        
        this.socket.on('history_result', (data) => {
            this.displayChatHistory(data.messages);
        });
        
        this.socket.on('translation_result', (data) => {
            this.showTranslationPreview(data.translated);
        });
        
        this.socket.on('incoming_call', (data) => {
            this.handleIncomingCall(data);
        });
        
        this.socket.on('call_answered', (data) => {
            this.handleCallAnswered(data);
        });
        
        this.socket.on('ice_candidate', (data) => {
            this.handleIceCandidate(data);
        });
        
        this.socket.on('call_ended', (data) => {
            this.handleCallEnded();
        });
    }
    
    logout() {
        localStorage.removeItem('chat_user');
        if (this.socket) {
            this.socket.disconnect();
        }
        location.reload();
    }
    
    async handleSearch(query) {
        if (!query || query.length < 2) {
            document.getElementById('search-results').innerHTML = '';
            return;
        }
        
        try {
            const response = await fetch(`/api/user/search?q=${encodeURIComponent(query)}`);
            const data = await response.json();
            
            const resultsDiv = document.getElementById('search-results');
            resultsDiv.innerHTML = data.users.map(user => `
                <div class="search-result-item" onclick="app.startChat('${user._id}', '${user.username}')">
                    ${user.username}
                </div>
            `).join('');
        } catch (err) {
            console.error('Search error:', err);
        }
    }
    
    startChat(userId, username) {
        this.currentChat = userId;
        document.getElementById('chat-with-username').textContent = username;
        document.getElementById('no-chat-selected').classList.add('hidden');
        document.getElementById('chat-container').classList.remove('hidden');
        document.getElementById('search-results').innerHTML = '';
        document.getElementById('search-user-input').value = '';
        
        this.loadChatHistory(userId);
        this.loadConversations();
    }
    
    async loadConversations() {
        try {
            const response = await fetch(`/api/user/conversations?userId=${this.currentUser.userId}`);
            const data = await response.json();
            
            const listDiv = document.getElementById('conversations-list');
            listDiv.innerHTML = data.conversations.map(conv => `
                <div class="conversation-item ${conv.userId === this.currentChat ? 'active' : ''}" 
                     onclick="app.startChat('${conv.userId}', '${conv.username}')">
                    <div class="conversation-username">${conv.username}</div>
                    <div class="conversation-last-message">${conv.lastMessage || 'No messages yet'}</div>
                    ${conv.unreadCount > 0 ? `<div class="unread-badge">${conv.unreadCount}</div>` : ''}
                </div>
            `).join('');
        } catch (err) {
            console.error('Load conversations error:', err);
        }
    }
    
    loadChatHistory(userId) {
        this.socket.emit('get_history', { withUser: userId, limit: 50 });
    }
    
    displayChatHistory(messages) {
        const container = document.getElementById('messages-container');
        container.innerHTML = '';
        
        messages.forEach(msg => {
            const type = msg.from === this.currentUser.userId ? 'sent' : 'received';
            this.displayMessage(msg, type, false);
        });
        
        this.scrollToBottom();
    }
    
    sendMessage() {
        const input = document.getElementById('message-input');
        const content = input.value.trim();
        
        if (!content || !this.currentChat) return;
        
        const messageData = {
            to: this.currentChat,
            content: content,
            originalLang: 'auto',
            translatedLang: 'en'
        };
        
        this.socket.emit('send_message', messageData);
        
        this.displayMessage({
            content: content,
            timestamp: new Date()
        }, 'sent');
        
        input.value = '';
        this.scrollToBottom();
    }
    
    displayMessage(msg, type, scroll = true) {
        const container = document.getElementById('messages-container');
        const time = new Date(msg.timestamp).toLocaleTimeString();
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.innerHTML = `
            <div class="message-bubble">${this.escapeHtml(msg.content)}</div>
            <div class="message-time">${time}</div>
        `;
        
        container.appendChild(messageDiv);
        
        if (scroll) {
            this.scrollToBottom();
        }
    }
    
    scrollToBottom() {
        const container = document.getElementById('messages-container');
        container.scrollTop = container.scrollHeight;
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    toggleTranslation() {
        this.translationEnabled = !this.translationEnabled;
        const btn = document.getElementById('translate-toggle-btn');
        btn.style.background = this.translationEnabled ? '#667eea' : '';
        btn.style.color = this.translationEnabled ? 'white' : '';
    }
    
    showTranslationPreview(translatedText) {
        const preview = document.getElementById('translation-preview');
        preview.textContent = `Translation: ${translatedText}`;
        preview.classList.remove('hidden');
        
        setTimeout(() => {
            preview.classList.add('hidden');
        }, 5000);
    }
    
    async startVoiceRecording() {
        try {
            const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
            recognition.lang = 'en-US';
            recognition.interimResults = false;
            
            recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                document.getElementById('message-input').value = transcript;
            };
            
            recognition.start();
        } catch (err) {
            alert('Speech recognition not supported in this browser');
        }
    }
    
    async startVideoCall() {
        if (!this.currentChat) return;
        
        try {
            this.localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            document.getElementById('local-video').srcObject = this.localStream;
            document.getElementById('video-call-modal').classList.remove('hidden');
            
            this.peerConnection = new RTCPeerConnection(this.rtcConfig);
            
            this.localStream.getTracks().forEach(track => {
                this.peerConnection.addTrack(track, this.localStream);
            });
            
            this.peerConnection.ontrack = (event) => {
                document.getElementById('remote-video').srcObject = event.streams[0];
            };
            
            this.peerConnection.onicecandidate = (event) => {
                if (event.candidate) {
                    this.socket.emit('ice_candidate', {
                        to: this.currentChat,
                        candidate: event.candidate
                    });
                }
            };
            
            const offer = await this.peerConnection.createOffer();
            await this.peerConnection.setLocalDescription(offer);
            
            this.socket.emit('video_call', {
                to: this.currentChat,
                signal: offer
            });
        } catch (err) {
            console.error('Video call error:', err);
            alert('Could not start video call');
        }
    }
    
    async handleIncomingCall(data) {
        const accept = confirm(`Incoming video call from ${data.fromUsername}. Accept?`);
        
        if (accept) {
            try {
                this.localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
                document.getElementById('local-video').srcObject = this.localStream;
                document.getElementById('video-call-modal').classList.remove('hidden');
                
                this.peerConnection = new RTCPeerConnection(this.rtcConfig);
                
                this.localStream.getTracks().forEach(track => {
                    this.peerConnection.addTrack(track, this.localStream);
                });
                
                this.peerConnection.ontrack = (event) => {
                    document.getElementById('remote-video').srcObject = event.streams[0];
                };
                
                this.peerConnection.onicecandidate = (event) => {
                    if (event.candidate) {
                        this.socket.emit('ice_candidate', {
                            to: data.from,
                            candidate: event.candidate
                        });
                    }
                };
                
                await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.signal));
                const answer = await this.peerConnection.createAnswer();
                await this.peerConnection.setLocalDescription(answer);
                
                this.socket.emit('answer_call', {
                    to: data.from,
                    signal: answer
                });
            } catch (err) {
                console.error('Answer call error:', err);
            }
        }
    }
    
    async handleCallAnswered(data) {
        await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.signal));
    }
    
    async handleIceCandidate(data) {
        if (this.peerConnection) {
            await this.peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
        }
    }
    
    endVideoCall() {
        if (this.peerConnection) {
            this.peerConnection.close();
            this.peerConnection = null;
        }
        
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
            this.localStream = null;
        }
        
        if (this.currentChat) {
            this.socket.emit('end_call', { to: this.currentChat });
        }
        
        document.getElementById('video-call-modal').classList.add('hidden');
        document.getElementById('local-video').srcObject = null;
        document.getElementById('remote-video').srcObject = null;
    }
    
    handleCallEnded() {
        this.endVideoCall();
    }
    
    openSocialLinksModal() {
        document.getElementById('social-links-modal').classList.remove('hidden');
    }
    
    openRemarkModal() {
        if (!this.currentChat) {
            alert('Please select a user first');
            return;
        }
        document.getElementById('remark-modal').classList.remove('hidden');
    }
    
    async saveSocialLinks() {
        const socialLinks = {
            tiktok: document.getElementById('tiktok-input').value,
            wechat: document.getElementById('wechat-input').value,
            lark: document.getElementById('lark-input').value,
            facebook: document.getElementById('facebook-input').value,
            whatsapp: document.getElementById('whatsapp-input').value,
            telegram: document.getElementById('telegram-input').value
        };
        
        try {
            const response = await fetch(`/api/user/${this.currentUser.userId}/social-links`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ socialLinks })
            });
            
            if (response.ok) {
                alert('Social links saved!');
                this.closeAllModals();
            }
        } catch (err) {
            console.error('Save social links error:', err);
        }
    }
    
    openSuggestionsModal() {
        document.getElementById('suggestions-modal').classList.remove('hidden');
        this.loadSuggestions();
    }
    
    async loadSuggestions() {
        try {
            const response = await fetch('/api/suggestions');
            const data = await response.json();
            
            const listDiv = document.getElementById('suggestions-list');
            listDiv.innerHTML = data.suggestions.map(sugg => `
                <div class="suggestion-item">
                    <h4>${sugg.username}</h4>
                    <p>${sugg.content}</p>
                    <div class="suggestion-votes">Votes: ${sugg.votes}</div>
                </div>
            `).join('');
        } catch (err) {
            console.error('Load suggestions error:', err);
        }
    }
    
    async submitSuggestion() {
        const content = document.getElementById('suggestion-input').value.trim();
        
        if (!content || content.length < 10) {
            alert('Suggestion must be at least 10 characters');
            return;
        }
        
        try {
            const response = await fetch('/api/suggestions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: this.currentUser.userId,
                    username: this.currentUser.username,
                    content
                })
            });
            
            if (response.ok) {
                document.getElementById('suggestion-input').value = '';
                this.loadSuggestions();
            }
        } catch (err) {
            console.error('Submit suggestion error:', err);
        }
    }
    
    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
    }
    
    markMessageAsRead(messageId) {
        // Mark message as read in the database
        // This could be implemented with an API call if needed
        console.log('Message marked as read:', messageId);
    }
    
    async saveRemark() {
        if (!this.currentChat) return;
        
        const remark = document.getElementById('remark-input').value.trim();
        
        if (!remark) {
            alert('Remark cannot be empty');
            return;
        }
        
        try {
            const response = await fetch('/api/user/remark', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: this.currentUser.userId,
                    targetUserId: this.currentChat,
                    remark
                })
            });
            
            if (response.ok) {
                alert('Remark saved!');
                document.getElementById('remark-input').value = '';
                this.closeAllModals();
            }
        } catch (err) {
            console.error('Save remark error:', err);
            alert('Failed to save remark');
        }
    }
}

const app = new ChatApp();
