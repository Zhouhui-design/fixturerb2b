const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    minlength: 3,
    maxlength: 30
  },
  socialLinks: {
    tiktok: { type: String, default: '' },
    wechat: { type: String, default: '' },
    lark: { type: String, default: '' },
    facebook: { type: String, default: '' },
    whatsapp: { type: String, default: '' },
    telegram: { type: String, default: '' }
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  lastActiveAt: {
    type: Date,
    default: Date.now
  },
  token: {
    type: String,
    required: true,
    unique: true
  }
});

userSchema.index({ username: 1 });
userSchema.index({ lastActiveAt: 1 });

module.exports = mongoose.model('User', userSchema);
