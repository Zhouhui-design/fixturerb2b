require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
const cron = require('node-cron');
const axios = require('axios');

const User = require('./models/User');
const Message = require('./models/Message');
const Remark = require('./models/Remark');
const Suggestion = require('./models/Suggestion');

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const suggestionRoutes = require('./routes/suggestion');

const { cleanupInactiveUsers } = require('./utils/cleanup');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../client')));

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/chat_system', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/suggestions', suggestionRoutes);

cron.schedule('0 2 * * *', async () => {
  console.log('Running cleanup for inactive users...');
  await cleanupInactiveUsers();
});

io.use(async (socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) {
    return next(new Error('Authentication required'));
  }
  try {
    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    const user = await User.findById(decoded.userId);
    if (!user) {
      return next(new Error('User not found'));
    }
    socket.userId = user._id;
    socket.user = user;
    next();
  } catch (err) {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  console.log(`User connected: ${socket.userId}`);
  
  User.findByIdAndUpdate(socket.userId, { lastActiveAt: new Date() }).exec();
  
  socket.join(`user_${socket.userId}`);
  
  socket.on('send_message', async (data) => {
    try {
      const { to, content, originalLang, translatedLang } = data;
      
      const message = new Message({
        from: socket.userId,
        to: to,
        content: content,
        originalLang: originalLang || 'auto',
        translatedLang: translatedLang || 'en'
      });
      await message.save();
      
      io.to(`user_${to}`).emit('receive_message', {
        id: message._id,
        from: socket.userId,
        fromUsername: socket.user.username,
        content: content,
        timestamp: message.timestamp,
        originalLang: message.originalLang
      });
      
      socket.emit('message_sent', { id: message._id, timestamp: message.timestamp });
    } catch (err) {
      console.error('Send message error:', err);
      socket.emit('message_error', { error: 'Failed to send message' });
    }
  });
  
  socket.on('get_history', async (data) => {
    try {
      const { withUser, limit = 50 } = data;
      const messages = await Message.find({
        $or: [
          { from: socket.userId, to: withUser },
          { from: withUser, to: socket.userId }
        ]
      }).sort({ timestamp: -1 }).limit(limit).sort({ timestamp: 1 });
      
      socket.emit('history_result', { messages, withUser });
    } catch (err) {
      console.error('Get history error:', err);
    }
  });
  
  socket.on('translate_message', async (data) => {
    try {
      const { text, targetLang } = data;
      const response = await axios.get(`https://api.mymemory.translated.net/get`, {
        params: {
          q: text,
          langpair: `auto|${targetLang}`
        }
      });
      const translatedText = response.data.responseData.translatedText;
      socket.emit('translation_result', { original: text, translated: translatedText, targetLang });
    } catch (err) {
      console.error('Translation error:', err);
      socket.emit('translation_error', { error: 'Translation failed' });
    }
  });
  
  socket.on('video_call', (data) => {
    const { to, signal } = data;
    io.to(`user_${to}`).emit('incoming_call', {
      from: socket.userId,
      fromUsername: socket.user.username,
      signal
    });
  });
  
  socket.on('answer_call', (data) => {
    const { to, signal } = data;
    io.to(`user_${to}`).emit('call_answered', {
      from: socket.userId,
      signal
    });
  });
  
  socket.on('ice_candidate', (data) => {
    const { to, candidate } = data;
    io.to(`user_${to}`).emit('ice_candidate', {
      from: socket.userId,
      candidate
    });
  });
  
  socket.on('end_call', (data) => {
    const { to } = data;
    io.to(`user_${to}`).emit('call_ended', {
      from: socket.userId
    });
  });
  
  socket.on('disconnect', () => {
    console.log(`User disconnected: ${socket.userId}`);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
