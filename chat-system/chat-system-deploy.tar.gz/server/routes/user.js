const express = require('express');
const User = require('../models/User');
const Remark = require('../models/Remark');
const Message = require('../models/Message');

const router = express.Router();

router.get('/search', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 2) {
      return res.status(400).json({ error: 'Search query must be at least 2 characters' });
    }
    
    const users = await User.find({
      username: { $regex: q, $options: 'i' }
    }).select('username _id').limit(20);
    
    res.json({ users });
  } catch (err) {
    console.error('Search error:', err);
    res.status(500).json({ error: 'Search failed' });
  }
});

router.get('/:userId', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).select('username socialLinks createdAt');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ user });
  } catch (err) {
    console.error('Get user error:', err);
    res.status(500).json({ error: 'Failed to get user' });
  }
});

router.put('/:userId/social-links', async (req, res) => {
  try {
    const { socialLinks } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.userId,
      { socialLinks },
      { new: true, runValidators: true }
    ).select('username socialLinks');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ user, message: 'Social links updated' });
  } catch (err) {
    console.error('Update social links error:', err);
    res.status(500).json({ error: 'Failed to update social links' });
  }
});

router.post('/remark', async (req, res) => {
  try {
    const { userId, targetUserId, remark } = req.body;
    
    if (!remark || remark.trim().length === 0) {
      return res.status(400).json({ error: 'Remark cannot be empty' });
    }
    
    const existingRemark = await Remark.findOneAndUpdate(
      { userId, targetUserId },
      { remark: remark.trim() },
      { upsert: true, new: true }
    );
    
    res.json({ remark: existingRemark, message: 'Remark saved' });
  } catch (err) {
    console.error('Save remark error:', err);
    res.status(500).json({ error: 'Failed to save remark' });
  }
});

router.get('/remark/:targetUserId', async (req, res) => {
  try {
    const { userId } = req.query;
    const remark = await Remark.findOne({ userId, targetUserId: req.params.targetUserId });
    
    res.json({ remark: remark ? remark.remark : null });
  } catch (err) {
    console.error('Get remark error:', err);
    res.status(500).json({ error: 'Failed to get remark' });
  }
});

router.get('/conversations', async (req, res) => {
  try {
    const { userId } = req.query;
    
    const conversations = await Message.aggregate([
      {
        $match: {
          $or: [
            { from: userId.toString() },
            { to: userId.toString() }
          ]
        }
      },
      {
        $sort: { timestamp: -1 }
      },
      {
        $group: {
          _id: {
            $cond: [
              { $eq: ['$from', userId.toString()] },
              '$to',
              '$from'
            ]
          },
          lastMessage: { $first: '$content' },
          lastTimestamp: { $first: '$timestamp' },
          unreadCount: {
            $sum: {
              $cond: [
                { $and: [
                  { $eq: ['$to', userId.toString()] },
                  { $eq: ['$read', false] }
                ]},
                1,
                0
              ]
            }
          }
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'user'
        }
      },
      {
        $unwind: '$user'
      },
      {
        $project: {
          userId: '$_id',
          username: '$user.username',
          lastMessage: 1,
          lastTimestamp: 1,
          unreadCount: 1
        }
      },
      {
        $sort: { lastTimestamp: -1 }
      }
    ]);
    
    res.json({ conversations });
  } catch (err) {
    console.error('Get conversations error:', err);
    res.status(500).json({ error: 'Failed to get conversations' });
  }
});

module.exports = router;
