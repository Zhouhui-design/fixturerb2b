const User = require('../models/User');
const Message = require('../models/Message');

async function cleanupInactiveUsers() {
  try {
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
    
    const inactiveUsers = await User.find({
      lastActiveAt: { $lt: oneYearAgo }
    });
    
    console.log(`Found ${inactiveUsers.length} inactive users to clean up`);
    
    for (const user of inactiveUsers) {
      await Message.deleteMany({
        $or: [
          { from: user._id },
          { to: user._id }
        ]
      });
      
      await user.deleteOne();
      console.log(`Deleted user: ${user.username}`);
    }
    
    console.log('Cleanup completed successfully');
  } catch (err) {
    console.error('Cleanup error:', err);
  }
}

module.exports = { cleanupInactiveUsers };
